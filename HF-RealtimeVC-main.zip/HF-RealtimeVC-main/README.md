# HF-RealtimeEVC

__"CONTINUOUS WAVELET TRANSFORM BASED HYBRID FILTERING FOR
REAL-TIME EMOTIONAL VOICE CONVERSION"__

Authors: Zhaojie Luo, Rui Liu, Shuyun Tang, Jun Baba, Yuichiro Yoshikawa, Hiroshi Ishiguro

This paper was submitted to ICASSP2022. 

## Speech samples


Speech samples are available at [demo page](https://ZhaojieL.github.io/HF-RealtimeVC/).




 
